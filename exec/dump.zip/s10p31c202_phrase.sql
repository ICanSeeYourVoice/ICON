-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p31c202
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phrase`
--

DROP TABLE IF EXISTS `phrase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phrase` (
  `phrase_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `text` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`phrase_id`),
  KEY `FKmb41tcl8a3v2g2ti6cspjqb5` (`member_id`),
  CONSTRAINT `FKmb41tcl8a3v2g2ti6cspjqb5` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phrase`
--

LOCK TABLES `phrase` WRITE;
/*!40000 ALTER TABLE `phrase` DISABLE KEYS */;
INSERT INTO `phrase` VALUES (6,'2024-05-07 02:55:18.034548','2024-05-07 02:55:18.034548','안녕하세요',9),(7,'2024-05-07 04:35:33.227671','2024-05-07 04:35:33.227671','안녕하신가요',9),(8,'2024-05-07 05:20:38.635500','2024-05-07 05:20:38.635500','안녕하신가요',9),(33,'2024-05-10 05:11:06.966644','2024-05-10 05:11:06.966644','안녕하십니까',23),(74,'2024-05-16 01:17:11.405634','2024-05-16 01:17:11.405634','청각장애인은 말을 못하는 경우가 있어서',12),(76,'2024-05-16 01:17:54.494322','2024-05-16 01:17:54.494322','text를 음성변환 시키는 기능이 있어요',12),(78,'2024-05-16 04:48:56.189751','2024-05-16 04:48:56.189751','안녕이건뭐야',3),(79,'2024-05-16 04:48:59.565666','2024-05-16 04:48:59.565666','안녕이건뭐야안녕이건뭐야안녕이건뭐야안녕이건뭐야안녕이건뭐야',3),(80,'2024-05-16 04:49:03.455690','2024-05-16 04:49:03.455690','안녕이건뭐야안녕이건뭐야안녕이건뭐야안녕이건뭐야',3),(92,'2024-05-17 07:47:17.088405','2024-05-17 07:47:17.088405','엄마',18),(94,'2024-05-18 07:58:58.727224','2024-05-18 07:58:58.727224','사랑해 우리 아기',14),(95,'2024-05-19 07:18:17.203836','2024-05-19 07:18:17.203836','아빠',31),(96,'2024-05-19 08:35:55.566887','2024-05-19 08:35:55.566887','엄마 아빠',14),(97,'2024-05-19 09:07:17.847654','2024-05-19 09:07:17.847654','안녕',16);
/*!40000 ALTER TABLE `phrase` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:10:00
