-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p31c202
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `smartthings_routine`
--

DROP TABLE IF EXISTS `smartthings_routine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smartthings_routine` (
  `smartthings_routine_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `scene_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `trigger_type` enum('CRY','TIRED','HUNGRY','DISCOMFORT','DANGER','PAIN') COLLATE utf8mb4_bin NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`smartthings_routine_id`),
  UNIQUE KEY `routine_uk` (`member_id`,`trigger_type`),
  CONSTRAINT `FKh4o216t3mfgnxyiw8ttqbhhn7` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smartthings_routine`
--

LOCK TABLES `smartthings_routine` WRITE;
/*!40000 ALTER TABLE `smartthings_routine` DISABLE KEYS */;
INSERT INTO `smartthings_routine` VALUES (52,'2024-05-16 06:10:02.035983','2024-05-16 06:10:02.035983','c6201d1a-02f3-4f70-8e0a-dba120d92a9e','HUNGRY',17),(53,'2024-05-16 06:10:06.686770','2024-05-19 07:35:14.728250','c6201d1a-02f3-4f70-8e0a-dba120d92a9e','PAIN',17),(54,'2024-05-16 06:10:08.500638','2024-05-16 06:10:10.609060','238d77be-7dce-4b1f-bfd1-2ec979ce668a','DANGER',17),(58,'2024-05-18 05:59:42.339187','2024-05-18 05:59:42.339187','fc181874-be66-4c0c-8ba5-830f4b519adf','TIRED',14),(59,'2024-05-18 05:59:44.781975','2024-05-18 05:59:44.781975','07ed7b62-b027-4c05-827e-4ede350f2318','HUNGRY',14),(60,'2024-05-18 05:59:46.891152','2024-05-18 05:59:46.891152','8cc0e33f-67a5-4643-bb15-01b06adb02d7','DISCOMFORT',14),(61,'2024-05-18 05:59:48.732646','2024-05-18 05:59:48.732646','7dd5dda9-227b-4dbc-a9ba-48e60b6eee02','PAIN',14),(62,'2024-05-18 05:59:51.098387','2024-05-18 05:59:51.098387','05168cae-0670-4761-902a-a88e42de983e','DANGER',14);
/*!40000 ALTER TABLE `smartthings_routine` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:10:02
